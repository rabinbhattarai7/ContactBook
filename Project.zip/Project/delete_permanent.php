<?php
require 'config.php'; // Database connection
require_login(); // Ensure user is logged in

if (isset($_GET['id'])) {  // Check if contact ID is provided
    $contact_id = (int)$_GET['id']; // 
    
    // Start transaction
    $pdo->beginTransaction();
    
    try {
        // Delete address first (due to foreign key constraint)
        $stmt = $pdo->prepare('DELETE FROM address WHERE contact_id = ?');
        $stmt->execute([$contact_id]);
        
        // Then delete the contact permanently
        $stmt = $pdo->prepare('DELETE FROM contacts WHERE id = ? AND user_id = ?');

        //  Execute with contact ID and user ID to ensure security
        $stmt->execute([$contact_id, $_SESSION['user_id']]);
        
        $pdo->commit(); // Commit transaction 
        
        // Redirect back to trash with success message
        header('Location: trash.php?permanently_deleted=1'); 
        exit; // Stop script execution after redirect

        // If any error occurs, rollback the transaction
    } catch (Exception $e) {
        $pdo->rollBack(); // Rollback transaction on error

        // Log the error for debugging (in real application, consider logging to a file)
        error_log('Permanent delete failed: ' . $e->getMessage()); 

        // Redirect back to trash with error message
        header('Location: trash.php?error=1');
        exit;
    }
}
// If no ID was provided, redirect back to trash page without message
header('Location: trash.php');
exit;
?>