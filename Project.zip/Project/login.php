<?php
require 'config.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $errors[] = 'Email and password are required.';
    } else {
        // Debug: Show what we're looking for
        error_log("Login attempt for: $email");
        
        $stmt = $pdo->prepare('SELECT id, password, name, role, is_active FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            error_log("User found: " . print_r($user, true));
            
            if (password_verify($password, $user['password'])) {
                if (!$user['is_active']) {
                    $errors[] = 'Your account has been deactivated.';
                } else {
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_role'] = $user['role'];

                    // Debug login success
                    error_log("Login successful for: $email, role: " . $user['role']);

                    if ($user['role'] === 'admin') {
                        header('Location: admin_dashboard.php');
                    } else {
                        header('Location: dashboard.php');
                    }
                    exit;
                }
            } else {
                error_log("Password verification failed for: $email");
                $errors[] = 'Invalid credentials.';
            }
        } else {
            error_log("No user found for: $email");
            $errors[] = 'Invalid credentials.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Contact Book</title>
    <link rel="stylesheet" href="assets/home.css">
</head>
<body>
    <header class="small-header">
        <div class="container">
            <h1 class="logo">Contact Book</h1>
        </div>
    </header>
    
    <main class="auth-page">
        <div class="auth-card">
            <h2>Welcome Back</h2>
            <p class="subtitle">Login to access your contacts</p>
            
            <!-- Debug info -->
           <!--   <div style="background: #e3f2fd; padding: 15px; border-radius: 5px; margin-bottom: 15px;">
                <h4>Admin Login Info:</h4>
                <p><strong>Email:</strong> admin@contactbook.com</p>
                <p><strong>Password:</strong> admin123</p>
                <p><small><a href="setup_admin.php" style="color: #1976d2;">Click here to setup admin user</a></small></p>
            </div>    -->
            
            <?php if (!empty($errors)): ?>
                <div class="error"><?php echo implode('<br>', array_map('htmlspecialchars', $errors)); ?></div>
            <?php endif; ?>

            <form method="post" action="login.php">
                <label>Email</label>
                <input type="email" name="email" placeholder="Enter your email" required value="admin@contactbook.com">

                <label>Password</label>
                <input type="password" name="password" placeholder="Enter your password" required value="admin123">

                <button type="submit" class="btn btn-primary full-width">Login</button>
            </form>

            <p class="switch">Don't have an account? <a href="register.php">Register here</a></p>
        </div>
    </main>
</body>
</html>