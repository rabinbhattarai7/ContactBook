<?php
// debug_admin.php - Enable error reporting and test admin dashboard
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Not logged in. Please login first.");
}

// Check if user is admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    die("You are not an admin. Current role: " . ($_SESSION['user_role'] ?? 'not set'));
}

echo "<h2>Debug Info - Admin Session</h2>";
echo "<pre>Session Data: " . print_r($_SESSION, true) . "</pre>";

// Test database connection
try {
    $pdo = new PDO('mysql:host=localhost;dbname=contact_book;charset=utf8mb4', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<p style='color: green;'>✅ Database connection successful</p>";
    
    // Test admin functions
    require_once 'config.php';
    echo "<p style='color: green;'>✅ Config.php loaded successfully</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Database error: " . $e->getMessage() . "</p>";
}

// Test if admin_header.php exists
if (file_exists('admin_header.php')) {
    echo "<p style='color: green;'>✅ admin_header.php exists</p>";
} else {
    echo "<p style='color: red;'>❌ admin_header.php NOT FOUND</p>";
}

// Test require_admin function
if (function_exists('require_admin')) {
    echo "<p style='color: green;'>✅ require_admin function exists</p>";
    require_admin();
    echo "<p style='color: green;'>✅ require_admin check passed</p>";
} else {
    echo "<p style='color: red;'>❌ require_admin function NOT FOUND</p>";
}
?>