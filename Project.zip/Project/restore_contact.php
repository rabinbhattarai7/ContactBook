<?php
// Include database configuration and authentication
require 'config.php';        // Database connection settings
require_login();              // Ensure user is logged in before proceeding

// Check if a contact ID was provided in the URL
if (isset($_GET['id'])) {
    // Sanitize the ID by converting to integer to prevent SQL injection
    $contact_id = (int)$_GET['id'];
    
    // Prepare SQL query to restore the contact
    // Sets deleted_at to NULL (soft delete reversal)
    // Also verifies the contact belongs to the logged-in user for security
    $stmt = $pdo->prepare('UPDATE contacts SET deleted_at = NULL WHERE id = ? AND user_id = ?');
    
    // Execute the query with the contact ID and user ID as parameters
    $stmt->execute([$contact_id, $_SESSION['user_id']]);
    
    // Redirect back to trash page with success message
    header('Location: trash.php?restored=1');
    exit; // Stop script execution after redirect
}

// If no ID was provided, redirect back to trash page without message
header('Location: trash.php');
exit; // Stop script execution
?>