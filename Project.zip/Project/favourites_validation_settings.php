<?php
require 'config.php';
require_login();

/* -----------------------------------------
   MIDDLE LAYER: VALIDATION LOGIC
--------------------------------------------*/

$errors = [];
$success = "";

// Form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // BOOLEAN → BIT
    $is_urgent = isset($_POST['is_urgent']) ? 1 : 0;

    // DECIMAL
    $priority_score = $_POST['priority_score'];
    if (!is_numeric($priority_score) || $priority_score < 0 || $priority_score > 10) {
        $errors[] = "Priority score must be a number between 0.00 and 10.00.";
    }

    // VARCHAR
    $colour_tag = trim($_POST['colour_tag']);
    if (strlen($colour_tag) > 20) {
        $errors[] = "Colour tag cannot exceed 20 characters.";
    }

    // TEXT
    $description = trim($_POST['description']);
    if (strlen($description) < 5) {
        $errors[] = "Description must be at least 5 characters.";
    }

    // Insert into database only if no errors
    if (empty($errors)) {

        /* -----------------------------------------
           DATA LAYER: INSERT INTO favourite_settings
        --------------------------------------------*/
        $stmt = $pdo->prepare("
            INSERT INTO favourite_settings 
            (user_id, is_urgent, priority_score, colour_tag, description)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $_SESSION['user_id'],
            $is_urgent,
            $priority_score,
            $colour_tag,
            $description
        ]);

        $success = "Settings saved successfully!";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Favourite Settings Validation</title>

    <style>
        body {
            background: #f4f6ff;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            padding-top: 40px;
        }

        .card {
            width: 420px;
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }

        h2 {
            margin-top: 0;
            text-align: center;
            color: #333;
        }

        label {
            font-weight: 600;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            margin: 8px 0 18px;
            border: 1px solid #ccc;
            border-radius: 8px;
        }

        .btn {
            width: 100%;
            background: #6b6bff;
            border: none;
            padding: 14px;
            color: #fff;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
        }

        .btn:hover {
            background: #5656f7;
        }

        .error {
            background: #ffe5e5;
            padding: 12px;
            border-left: 5px solid red;
            border-radius: 8px;
            margin-bottom: 10px;
            color: #a70000;
        }

        .success {
            background: #e8ffe8;
            padding: 12px;
            border-left: 5px solid #00b900;
            border-radius: 8px;
            margin-bottom: 10px;
            color: #006600;
        }
    </style>
</head>

<body>

<div class="card">

    <h2>Favourite Settings Form</h2>

    <!-- Success message -->
    <?php if (!empty($success)): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- Error messages -->
    <?php foreach ($errors as $error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endforeach; ?>

    <!-- PRESENTATION LAYER: FORM -->
    <form method="POST">

        <!-- BOOLEAN -->
        <label>Is this urgent?</label>
        <input type="checkbox" name="is_urgent">

        <!-- DECIMAL -->
        <label>Priority Score (0.00 - 10.00):</label>
        <input type="number" step="0.01" name="priority_score" placeholder="e.g. 5.25">

        <!-- VARCHAR -->
        <label>Colour Tag:</label>
        <input type="text" name="colour_tag" placeholder="e.g. Red, Blue...">

        <!-- TEXT -->
        <label>Description:</label>
        <textarea name="description" rows="3" placeholder="Write a short description..."></textarea>

        <button type="submit" class="btn">Save Settings</button>

    </form>
</div>

</body>
</html>