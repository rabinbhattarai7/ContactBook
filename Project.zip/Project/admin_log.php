<?php
require 'config.php';
require 'admin_header.php';
require_admin();

// Handle log clearing
if (isset($_POST['clear_logs']) && $_POST['clear_logs'] === '1') {
    $pdo->exec('DELETE FROM admin_logs');
    log_admin_action('logs_cleared', 'Cleared all admin logs');
    $success_message = "All logs have been cleared successfully.";
}

// Handle export to CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="admin_logs_' . date('Y-m-d_H-i-s') . '.csv"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'Admin', 'Action', 'Description', 'IP Address', 'User Agent', 'Timestamp']);
    
    $logs = $pdo->query("
        SELECT al.*, u.name as admin_name 
        FROM admin_logs al 
        LEFT JOIN users u ON al.admin_id = u.id 
        ORDER BY al.created_at DESC
    ")->fetchAll();
    
    foreach ($logs as $log) {
        fputcsv($output, [
            $log['id'],
            $log['admin_name'],
            $log['action'],
            $log['description'],
            $log['ip_address'],
            $log['user_agent'],
            $log['created_at']
        ]);
    }
    fclose($output);
    exit;
}

// Search and filter functionality
$search = trim($_GET['search'] ?? '');
$action_filter = $_GET['action_filter'] ?? '';
$admin_filter = $_GET['admin_filter'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Build query with filters
$where_conditions = ['1=1'];
$params = [];

if ($search) {
    $where_conditions[] = '(al.action LIKE ? OR al.description LIKE ? OR u.name LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($action_filter) {
    $where_conditions[] = 'al.action = ?';
    $params[] = $action_filter;
}

if ($admin_filter) {
    $where_conditions[] = 'al.admin_id = ?';
    $params[] = $admin_filter;
}

if ($date_from) {
    $where_conditions[] = 'DATE(al.created_at) >= ?';
    $params[] = $date_from;
}

if ($date_to) {
    $where_conditions[] = 'DATE(al.created_at) <= ?';
    $params[] = $date_to;
}

$where_clause = implode(' AND ', $where_conditions);

// Get total logs for pagination
$total_logs = $pdo->prepare("
    SELECT COUNT(*) 
    FROM admin_logs al 
    LEFT JOIN users u ON al.admin_id = u.id 
    WHERE $where_clause
");
$total_logs->execute($params);
$total_logs_count = $total_logs->fetchColumn();

// Pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;
$total_pages = ceil($total_logs_count / $limit);

// Get logs with pagination and filters
$stmt = $pdo->prepare("
    SELECT al.*, u.name as admin_name, u.email as admin_email
    FROM admin_logs al 
    LEFT JOIN users u ON al.admin_id = u.id 
    WHERE $where_clause 
    ORDER BY al.created_at DESC 
    LIMIT ? OFFSET ?
");
$params[] = $limit;
$params[] = $offset;
$stmt->execute($params);
$logs = $stmt->fetchAll();

// Get statistics for the dashboard
$stats = [
    'total_logs' => $pdo->query("SELECT COUNT(*) FROM admin_logs")->fetchColumn(),
    'today_logs' => $pdo->query("SELECT COUNT(*) FROM admin_logs WHERE DATE(created_at) = CURDATE()")->fetchColumn(),
    'unique_admins' => $pdo->query("SELECT COUNT(DISTINCT admin_id) FROM admin_logs")->fetchColumn(),
    'total_actions' => $pdo->query("SELECT COUNT(DISTINCT action) FROM admin_logs")->fetchColumn(),
];

// Get top actions
$top_actions = $pdo->query("
    SELECT action, COUNT(*) as count 
    FROM admin_logs 
    GROUP BY action 
    ORDER BY count DESC 
    LIMIT 10
")->fetchAll();

// Get recent admins
$recent_admins = $pdo->query("
    SELECT u.name, u.email, MAX(al.created_at) as last_action, COUNT(al.id) as action_count
    FROM admin_logs al 
    LEFT JOIN users u ON al.admin_id = u.id 
    WHERE u.role = 'admin'
    GROUP BY al.admin_id 
    ORDER BY last_action DESC 
    LIMIT 5
")->fetchAll();

// Get available actions for filter
$available_actions = $pdo->query("SELECT DISTINCT action FROM admin_logs ORDER BY action")->fetchAll(PDO::FETCH_COLUMN);

// Get available admins for filter
$available_admins = $pdo->query("
    SELECT DISTINCT u.id, u.name 
    FROM admin_logs al 
    LEFT JOIN users u ON al.admin_id = u.id 
    ORDER BY u.name
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Logs - Admin Panel</title>
    <style>
        :root {
            --primary: #5d6df7;
            --primary-dark: #4a5bd9;
            --primary-light: #e8edff;
            --secondary: #6b7280;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --light: #f8fafc;
            --dark: #1f2937;
            --darker: #111827;
            --border: #e5e7eb;
            --shadow: rgba(0, 0, 0, 0.08);
        }

        .admin-container {
            max-width: 1600px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .page-header {
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 4px 20px var(--shadow);
            margin-bottom: 30px;
        }

        .page-header h1 {
            color: var(--darker);
            margin: 0 0 10px 0;
            font-size: 28px;
        }

        .page-header p {
            color: var(--secondary);
            margin: 0;
        }

        /* Stats Bar */
        .stats-bar {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 10px var(--shadow);
            text-align: center;
            border-left: 4px solid var(--primary);
        }

        .stat-number {
            font-size: 32px;
            font-weight: 800;
            color: var(--primary);
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 14px;
            color: var(--secondary);
            font-weight: 600;
        }

        /* Analytics Grid */
        .analytics-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 25px;
            margin-bottom: 30px;
        }

        @media (max-width: 1024px) {
            .analytics-grid {
                grid-template-columns: 1fr;
            }
        }

        .analytics-card {
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 4px 20px var(--shadow);
        }

        .analytics-card h3 {
            color: var(--darker);
            margin: 0 0 20px 0;
            font-size: 18px;
            border-bottom: 2px solid var(--primary-light);
            padding-bottom: 10px;
        }

        /* Top Actions */
        .action-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid var(--border);
        }

        .action-item:last-child {
            border-bottom: none;
        }

        .action-name {
            font-weight: 500;
            color: var(--dark);
        }

        .action-count {
            background: var(--primary-light);
            color: var(--primary);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        /* Recent Admins */
        .admin-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid var(--border);
        }

        .admin-item:last-child {
            border-bottom: none;
        }

        .admin-info {
            display: flex;
            flex-direction: column;
        }

        .admin-name {
            font-weight: 600;
            color: var(--dark);
        }

        .admin-email {
            font-size: 12px;
            color: var(--secondary);
        }

        .admin-stats {
            text-align: right;
        }

        .admin-action-count {
            background: var(--success);
            color: white;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }

        .admin-last-action {
            font-size: 11px;
            color: var(--secondary);
            margin-top: 2px;
        }

        /* Filters */
        .filters-card {
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 4px 20px var(--shadow);
            margin-bottom: 25px;
        }

        .filters-form {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr 1fr auto;
            gap: 15px;
            align-items: end;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
        }

        .filter-group label {
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--dark);
            font-size: 14px;
        }

        .filter-group input, .filter-group select {
            padding: 10px 12px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 14px;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-success:hover {
            background: #059669;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        .btn-secondary {
            background: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            background: #4b5563;
        }

        /* Logs Table */
        .logs-table-card {
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 4px 20px var(--shadow);
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 15px 20px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }

        th {
            background: var(--light);
            font-weight: 600;
            color: var(--dark);
            font-size: 14px;
        }

        .log-action {
            font-weight: 600;
            color: var(--dark);
        }

        .log-description {
            max-width: 300px;
            word-wrap: break-word;
        }

        .log-admin {
            font-weight: 500;
            color: var(--primary);
        }

        .log-timestamp {
            color: var(--secondary);
            font-size: 13px;
            white-space: nowrap;
        }

        .log-ip {
            font-family: monospace;
            font-size: 12px;
            color: var(--secondary);
        }

        .action-badge {
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
            display: inline-block;
        }

        .action-login { background: #d1fae5; color: #065f46; }
        .action-create { background: #dbeafe; color: #1e40af; }
        .action-update { background: #fef3c7; color: #92400e; }
        .action-delete { background: #fee2e2; color: #991b1b; }
        .action-system { background: #f3f4f6; color: #374151; }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 30px;
        }

        .pagination a, .pagination span {
            padding: 8px 16px;
            background: white;
            border: 1px solid var(--border);
            border-radius: 8px;
            text-decoration: none;
            color: var(--dark);
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .pagination a:hover, .pagination a.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .pagination span {
            background: var(--light);
            color: var(--secondary);
        }

        /* Messages */
        .success {
            background: #f0fdf4;
            color: var(--success);
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #bbf7d0;
        }

        .warning {
            background: #fffbeb;
            color: #d97706;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #fed7aa;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--secondary);
        }

        .empty-state h3 {
            margin-bottom: 10px;
            color: var(--dark);
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .filters-form {
                grid-template-columns: 1fr 1fr 1fr;
            }
        }

        @media (max-width: 768px) {
            .filters-form {
                grid-template-columns: 1fr;
            }
            
            .stats-bar {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            table {
                font-size: 14px;
            }
            
            th, td {
                padding: 10px 12px;
            }
            
            .log-description {
                max-width: 200px;
            }
        }

        @media (max-width: 480px) {
            .stats-bar {
                grid-template-columns: 1fr;
            }
            
            .analytics-grid {
                grid-template-columns: 1fr;
            }
        }

        .user-agent {
            max-width: 200px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: 12px;
            color: var(--secondary);
        }
    </style>
</head>
<body>

<main class="admin-container">
    <!-- Page Header -->
    <div class="page-header">
        <h1>Admin Activity Logs</h1>
        <p>Monitor and track all administrator activities in the system</p>
    </div>

    <!-- Success Message -->
    <?php if (isset($success_message)): ?>
        <div class="success">✅ <?= htmlspecialchars($success_message) ?></div>
    <?php endif; ?>

    <!-- Statistics -->
    <div class="stats-bar">
        <div class="stat-card">
            <div class="stat-number"><?= $stats['total_logs'] ?></div>
            <div class="stat-label">Total Log Entries</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $stats['today_logs'] ?></div>
            <div class="stat-label">Today's Activities</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $stats['unique_admins'] ?></div>
            <div class="stat-label">Active Administrators</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $stats['total_actions'] ?></div>
            <div class="stat-label">Unique Action Types</div>
        </div>
    </div>

    <!-- Analytics Grid -->
    <div class="analytics-grid">
        <!-- Top Actions -->
        <div class="analytics-card">
            <h3>📊 Most Frequent Actions</h3>
            <?php if (!empty($top_actions)): ?>
                <?php foreach ($top_actions as $action): ?>
                    <div class="action-item">
                        <span class="action-name"><?= htmlspecialchars($action['action']) ?></span>
                        <span class="action-count"><?= $action['count'] ?></span>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="color: var(--secondary); text-align: center; padding: 20px;">No actions recorded yet</p>
            <?php endif; ?>
        </div>

        <!-- Recent Admins -->
        <div class="analytics-card">
            <h3>👥 Recent Administrators</h3>
            <?php if (!empty($recent_admins)): ?>
                <?php foreach ($recent_admins as $admin): ?>
                    <div class="admin-item">
                        <div class="admin-info">
                            <span class="admin-name"><?= htmlspecialchars($admin['name']) ?></span>
                            <span class="admin-email"><?= htmlspecialchars($admin['email']) ?></span>
                        </div>
                        <div class="admin-stats">
                            <span class="admin-action-count"><?= $admin['action_count'] ?> actions</span>
                            <div class="admin-last-action"><?= date('M j, g:i A', strtotime($admin['last_action'])) ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="color: var(--secondary); text-align: center; padding: 20px;">No admin activity yet</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Action Buttons -->
    <div class="action-buttons">
        <a href="?export=csv" class="btn btn-success">
            <span>📥</span>
            Export to CSV
        </a>
        <form method="post" style="display: inline;" onsubmit="return confirm('WARNING: This will permanently delete ALL log entries. This action cannot be undone! Are you sure you want to clear all logs?')">
            <input type="hidden" name="clear_logs" value="1">
            <button type="submit" class="btn btn-danger">
                <span>🗑️</span>
                Clear All Logs
            </button>
        </form>
        <a href="admin_dashboard.php" class="btn btn-secondary">
            <span>←</span>
            Back to Dashboard
        </a>
    </div>

    <!-- Warning for empty logs -->
    <?php if ($total_logs_count == 0 && !$search && !$action_filter && !$admin_filter && !$date_from && !$date_to): ?>
        <div class="warning">
            ℹ️ No log entries found. Admin activities will appear here as they occur.
        </div>
    <?php endif; ?>

    <!-- Filters -->
    <div class="filters-card">
        <form method="get" class="filters-form">
            <div class="filter-group">
                <label for="search">Search Logs</label>
                <input type="text" id="search" name="search" placeholder="Search action, description, or admin..." 
                       value="<?= htmlspecialchars($search) ?>">
            </div>
            
            <div class="filter-group">
                <label for="action_filter">Action Type</label>
                <select id="action_filter" name="action_filter">
                    <option value="">All Actions</option>
                    <?php foreach ($available_actions as $action): ?>
                        <option value="<?= htmlspecialchars($action) ?>" <?= $action_filter === $action ? 'selected' : '' ?>>
                            <?= htmlspecialchars($action) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="filter-group">
                <label for="admin_filter">Administrator</label>
                <select id="admin_filter" name="admin_filter">
                    <option value="">All Admins</option>
                    <?php foreach ($available_admins as $admin): ?>
                        <option value="<?= $admin['id'] ?>" <?= $admin_filter == $admin['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($admin['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="filter-group">
                <label for="date_from">From Date</label>
                <input type="date" id="date_from" name="date_from" value="<?= htmlspecialchars($date_from) ?>">
            </div>
            
            <div class="filter-group">
                <label for="date_to">To Date</label>
                <input type="date" id="date_to" name="date_to" value="<?= htmlspecialchars($date_to) ?>">
            </div>
            
            <div class="filter-group">
                <button type="submit" class="btn btn-primary">Apply Filters</button>
                <?php if ($search || $action_filter || $admin_filter || $date_from || $date_to): ?>
                    <a href="admin_log.php" class="btn btn-secondary" style="margin-top: 8px;">Clear Filters</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Logs Table -->
    <div class="logs-table-card">
        <?php if (empty($logs)): ?>
            <div class="empty-state">
                <h3>No log entries found</h3>
                <p><?= ($search || $action_filter || $admin_filter || $date_from || $date_to) ? 'Try adjusting your filters.' : 'No admin activities have been logged yet.' ?></p>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Action</th>
                        <th>Description</th>
                        <th>Administrator</th>
                        <th>IP Address</th>
                        <th>User Agent</th>
                        <th>Timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                    <tr>
                        <td style="font-family: monospace; color: var(--secondary);">#<?= $log['id'] ?></td>
                        <td>
                            <span class="log-action"><?= htmlspecialchars($log['action']) ?></span>
                        </td>
                        <td class="log-description"><?= htmlspecialchars($log['description'] ?? 'N/A') ?></td>
                        <td>
                            <span class="log-admin"><?= htmlspecialchars($log['admin_name'] ?? 'Unknown') ?></span>
                            <?php if ($log['admin_email']): ?>
                                <div style="font-size: 11px; color: var(--secondary);"><?= htmlspecialchars($log['admin_email']) ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="log-ip"><?= htmlspecialchars($log['ip_address'] ?? 'N/A') ?></td>
                        <td class="user-agent" title="<?= htmlspecialchars($log['user_agent'] ?? 'N/A') ?>">
                            <?= htmlspecialchars($log['user_agent'] ?? 'N/A') ?>
                        </td>
                        <td class="log-timestamp">
                            <?= date('M j, Y', strtotime($log['created_at'])) ?>
                            <div style="font-size: 11px; color: var(--secondary);">
                                <?= date('g:i:s A', strtotime($log['created_at'])) ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?= $page - 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?><?= $action_filter ? '&action_filter=' . urlencode($action_filter) : '' ?><?= $admin_filter ? '&admin_filter=' . $admin_filter : '' ?><?= $date_from ? '&date_from=' . $date_from : '' ?><?= $date_to ? '&date_to=' . $date_to : '' ?>">‹ Previous</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <?php if ($i == $page): ?>
                <span class="active"><?= $i ?></span>
            <?php else: ?>
                <a href="?page=<?= $i ?><?= $search ? '&search=' . urlencode($search) : '' ?><?= $action_filter ? '&action_filter=' . urlencode($action_filter) : '' ?><?= $admin_filter ? '&admin_filter=' . $admin_filter : '' ?><?= $date_from ? '&date_from=' . $date_from : '' ?><?= $date_to ? '&date_to=' . $date_to : '' ?>"><?= $i ?></a>
            <?php endif; ?>
        <?php endfor; ?>

        <?php if ($page < $total_pages): ?>
            <a href="?page=<?= $page + 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?><?= $action_filter ? '&action_filter=' . urlencode($action_filter) : '' ?><?= $admin_filter ? '&admin_filter=' . $admin_filter : '' ?><?= $date_from ? '&date_from=' . $date_from : '' ?><?= $date_to ? '&date_to=' . $date_to : '' ?>">Next ›</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Results Info -->
    <?php if (!empty($logs)): ?>
        <div style="text-align: center; color: var(--secondary); margin-top: 15px;">
            Showing <?= count($logs) ?> of <?= $total_logs_count ?> log entries
            <?php if ($search || $action_filter || $admin_filter || $date_from || $date_to): ?>
                (filtered)
            <?php endif; ?>
        </div>
    <?php endif; ?>
</main>

<script>
    // Set max date for date filters to today
    document.addEventListener('DOMContentLoaded', function() {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('date_from').max = today;
        document.getElementById('date_to').max = today;
        
        // Validate date range
        const dateFrom = document.getElementById('date_from');
        const dateTo = document.getElementById('date_to');
        
        dateFrom.addEventListener('change', function() {
            if (dateTo.value && this.value > dateTo.value) {
                dateTo.value = this.value;
            }
        });
        
        dateTo.addEventListener('change', function() {
            if (dateFrom.value && this.value < dateFrom.value) {
                dateFrom.value = this.value;
            }
        });
    });
</script>

</body>
</html>