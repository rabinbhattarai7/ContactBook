<?php
// config.php - PDO connection and login helper
session_start();

// Try different common MySQL configurations
$DB_HOST = 'localhost';  


$DB_NAME = 'contact_book';
$DB_USER = 'root';
$DB_PASS = '';  // Default XAMPP/WAMP password is empty
// $DB_PASS = 'root';      // Common alternative password

$dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4";

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, $options);
} catch (Exception $e) {
    // Show more detailed error information
    echo "<div style='background: #f8d7da; color: #721c24; padding: 20px; border: 1px solid #f5c6cb; border-radius: 5px; margin: 20px;'>";
    echo "<h3>Database Connection Error</h3>";
    echo "<p><strong>Error:</strong> " . $e->getMessage() . "</p>";
    echo "<p><strong>Host:</strong> " . $DB_HOST . "</p>";
    echo "<p><strong>Database:</strong> " . $DB_NAME . "</p>";
    echo "<p><strong>Username:</strong> " . $DB_USER . "</p>";
    echo "<p>Please check:</p>";
    echo "<ul>";
    echo "<li>Is MySQL server running?</li>";
    echo "<li>Are the database credentials correct?</li>";
    echo "<li>Does the database 'contact_book' exist?</li>";
    echo "<li>Is the MySQL port (usually 3306) open?</li>";
    echo "</ul>";
    echo "</div>";
    exit;
}

// Helper function to check login
if (!function_exists('require_login')) {
    function require_login() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: login.php');
            exit();
        }
    }
}

// Helper function to check admin access
if (!function_exists('require_admin')) {
    function require_admin() {
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
            header('Location: login.php');
            exit();
        }
    }
}

// Admin logging function
if (!function_exists('log_admin_action')) {
    function log_admin_action($action, $description = '') {
        global $pdo;
        try {
            $stmt = $pdo->prepare('INSERT INTO admin_logs (admin_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([
                $_SESSION['user_id'], 
                $action, 
                $description,
                $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
            ]);
        } catch (Exception $e) {
            error_log('Admin logging failed: ' . $e->getMessage());
        }
    }
}

// Security questions function
if (!function_exists('get_security_questions')) {
    function get_security_questions() {
        return [
            "What was the name of your first pet?",
            "What city were you born in?",
            "What is your mother's maiden name?",
            "What was the name of your elementary school?",
            "What was your childhood nickname?",
            "What is the name of your favorite childhood friend?",
            "What street did you grow up on?",
            "What was the make of your first car?",
            "What is your favorite book?",
            "What is the name of the company of your first job?"
        ];
    }
}

// Email validation function
if (!function_exists('validate_email')) {
    function validate_email($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
}

// Security data validation
if (!function_exists('validate_security_data')) {
    function validate_security_data($question, $answer) {
        $errors = [];
        $security_questions = get_security_questions();
        
        if (!in_array($question, $security_questions)) {
            $errors[] = 'Please select a valid security question.';
        }
        
        if (strlen(trim($answer)) < 2) {
            $errors[] = 'Security answer must be at least 2 characters long.';
        }
        
        if (strlen(trim($answer)) > 100) {
            $errors[] = 'Security answer must not exceed 100 characters.';
        }
        
        return $errors;
    }
}
?>