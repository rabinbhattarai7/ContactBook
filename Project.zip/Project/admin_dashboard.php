<?php
// admin_dashboard.php - Enable error reporting at the top
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'config.php';
require 'admin_header.php';
require_admin();

// Get statistics with error handling
try {
    $total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $total_contacts = $pdo->query("SELECT COUNT(*) FROM contacts WHERE deleted_at IS NULL")->fetchColumn();
    $total_admins = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
    $active_users = $pdo->query("SELECT COUNT(*) FROM users WHERE is_active = 1")->fetchColumn();
} catch (Exception $e) {
    // If there's an error with the queries, set defaults
    $total_users = $total_contacts = $total_admins = $active_users = 0;
    error_log("Dashboard statistics error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Contact Book</title>
    <style>
        :root {
            --primary: #5d6df7;
            --primary-dark: #4a5bd9;
            --primary-light: #e8edff;
            --secondary: #6b7280;
            --accent: #8b5cf6;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --light: #f8fafc;
            --dark: #1f2937;
            --darker: #111827;
            --border: #e5e7eb;
            --shadow: rgba(0, 0, 0, 0.08);
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            font-family: "Segoe UI", Tahoma, sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }

        .admin-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px 60px;
        }

        .welcome-section {
            background: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 4px 20px var(--shadow);
            margin-bottom: 30px;
            text-align: center;
        }

        .welcome-section h1 {
            color: var(--darker);
            margin-bottom: 10px;
            font-size: 32px;
        }

        .welcome-section p {
            color: var(--secondary);
            font-size: 18px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 4px 20px var(--shadow);
            text-align: center;
            border-left: 5px solid var(--primary);
        }

        .stat-card h3 {
            color: var(--secondary);
            margin-bottom: 10px;
            font-size: 16px;
        }

        .stat-card .number {
            font-size: 36px;
            font-weight: 800;
            color: var(--primary);
        }

        .admin-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
        }

        .action-card {
            background: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 4px 20px var(--shadow);
            text-decoration: none;
            color: var(--dark);
            transition: all 0.3s ease;
            border: 1px solid var(--border);
        }

        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            border-color: var(--primary);
        }

        .action-card h3 {
            color: var(--primary);
            margin-bottom: 10px;
            font-size: 20px;
        }

        .action-card p {
            color: var(--secondary);
            margin: 0;
        }

        .icon {
            font-size: 40px;
            margin-bottom: 15px;
        }

        footer {
            text-align: center;
            padding: 25px;
            background: white;
            border-top: 1px solid var(--border);
            margin-top: 40px;
            color: var(--secondary);
        }
    </style>
</head>
<body>

<main class="admin-container">
    <!-- Welcome Section -->
    <section class="welcome-section">
        <h1>Admin Dashboard</h1>
        <p>Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>! Manage your Contact Book system.</p>
    </section>

    <!-- Statistics -->
    <section class="stats-grid">
        <div class="stat-card">
            <h3>Total Users</h3>
            <div class="number"><?php echo $total_users; ?></div>
        </div>
        <div class="stat-card">
            <h3>Total Contacts</h3>
            <div class="number"><?php echo $total_contacts; ?></div>
        </div>
        <div class="stat-card">
            <h3>Administrators</h3>
            <div class="number"><?php echo $total_admins; ?></div>
        </div>
        <div class="stat-card">
            <h3>Active Users</h3>
            <div class="number"><?php echo $active_users; ?></div>
        </div>
    </section>

    <!-- Admin Actions -->
    <section class="admin-actions">
        <a href="admin_users.php" class="action-card">
            <div class="icon">👥</div>
            <h3>Manage Users</h3>
            <p>View, edit, and manage all system users</p>
        </a>

        <a href="admin_log.php" class="action-card">
            <div class="icon">📊</div>
            <h3>View Logs</h3>
            <p>Monitor admin activities and system logs</p>
        </a>

        <a href="admin_users_add.php" class="action-card">
            <div class="icon">➕</div>
            <h3>Add New User</h3>
            <p>Create new user accounts manually</p>
        </a>

        <a href="dashboard.php" class="action-card">
            <div class="icon">📱</div>
            <h3>User Dashboard</h3>
            <p>Switch to regular user interface</p>
        </a>
    </section>
</main>

<footer>
    <p>&copy; 2025 Contact Book - Admin Panel</p>
</footer>

</body>
</html>