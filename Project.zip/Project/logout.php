<?php
session_start(); // Start session system
$_SESSION = [];  // Clear all user data
session_destroy();      // End the session completely
header('Location: login.php');  // Go to login page
exit; // Stop running this page