<?php 
require 'config.php';        
require 'header.php';       
require_login();             

// ----------------------------------------------------
// VALIDATION: ID must exist to know which favourite 
// ----------------------------------------------------
if (!isset($_GET['id'])) {
    header("Location: favourites.php");
    exit;
}

// Get the favourite contact ID from the URL safely
$id = (int)$_GET['id'];


// ----------------------------------------------------
// FUNCTION: Load a favourite contact securely
// Ensures:
//   ✔ contact exists
//   ✔ belongs to logged-in user
//   ✔ is actually marked as favourite
// Prevents one user editing another user's data.
// ----------------------------------------------------
function loadContact($pdo, $id) {
    $stmt = $pdo->prepare("
        SELECT * FROM contacts 
        WHERE id = ? AND user_id = ? AND is_favourite = 1
    ");
    $stmt->execute([$id, $_SESSION['user_id']]);
    return $stmt->fetch();
}

// Fetch the contact data
$contact = loadContact($pdo, $id);

// SECURITY CHECK: If contact doesn't belong to logged-in user or doesn't exist → block access
if (!$contact) {
    exit("❌ Favourite contact not found or you are not allowed to edit it.");
}

// Store validation errors
$errors = [];


// ----------------------------------------------------
// If redirected due to validation error, restore
// previous validation messages and reload data.
// ----------------------------------------------------
if (!empty($_SESSION['errors'])) {
    $errors = $_SESSION['errors'];
    unset($_SESSION['errors']);
    $contact = loadContact($pdo, $id);
}


// ----------------------------------------------------
// NEW: Load Extra Favourite Settings (if they exist)
// ----------------------------------------------------
$settingsStmt = $pdo->prepare("
    SELECT * FROM favourite_settings 
    WHERE user_id = ? AND contact_id = ?
");
$settingsStmt->execute([$_SESSION['user_id'], $id]);
$settings = $settingsStmt->fetch();


// ----------------------------------------------------
// MAIN FORM SUBMISSION: EDIT Favourite Contact
// ----------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // SECURITY: Ensure the logged-in user still owns this contact
    $ownerCheck = $pdo->prepare("SELECT id FROM contacts WHERE id = ? AND user_id = ?");
    $ownerCheck->execute([$id, $_SESSION['user_id']]);
    if (!$ownerCheck->fetch()) {
        exit("❌ You cannot edit this favourite contact.");
    }

    // Get updated values
    $name  = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $note  = trim($_POST['reminder_note']);
    $date  = $_POST['reminder_date'];
    $time  = $_POST['reminder_time'];

    // Date & time for validation
    $today = date('Y-m-d');
    $now   = date('H:i');

    $errors = [];

    // BACKEND VALIDATION (REQUIRED FIELDS)
    if ($name === '')  $errors[] = "Name is required.";
    if ($phone === '') $errors[] = "Phone is required.";

    // VALIDATION: Reminder note length must not exceed 100 characters
    if (!empty($note) && strlen($note) > 100) {
        $errors[] = "Note cannot be more than 100 characters.";
    }

    // VALIDATION: Reminder date cannot be in the past
    if ($date !== "" && $date < $today) {
        $errors[] = "Reminder date cannot be in the past.";
    }

    // VALIDATION: If reminder is today, time must not be earlier than current time
    if ($date === $today) {
        if (!empty($time) && $time < $now) {
            $errors[] = "Reminder time cannot be earlier than the current time.";
        }
    }

    // VALIDATION: Email format check (if provided)
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }


    // ⭐ EXTRA SETTINGS (OPTIONAL)
$is_urgent = isset($_POST['is_urgent']) ? 1 : 0;

// Priority Score — optional
$priority_score = trim($_POST['priority_score']);
if ($priority_score !== "") {
    if (!is_numeric($priority_score) || $priority_score < 0 || $priority_score > 10) {
        $errors[] = "Priority score must be between 0 and 10.";
    }
} else {
    $priority_score = null; // allow empty
}

// Colour Tag — optional
$colour_tag = trim($_POST['colour_tag']);
if ($colour_tag === "") {
    $colour_tag = null;
} else if (strlen($colour_tag) > 20) {
    $errors[] = "Colour tag cannot exceed 20 characters.";
}

// Description — optional
$description = trim($_POST['description']);
if ($description === "") {
    $description = null;
} else if (strlen($description) < 5) {
    $errors[] = "Description must be at least 5 characters long.";
}



    // If validation fails → redirect back with errors
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header("Location: edit_favourites.php?id=" . $id);
        exit;
    }

    // ----------------------------------------------------
    // BACKEND UPDATE (EDIT FUNCTIONALITY)
    // ----------------------------------------------------
    $stmt = $pdo->prepare("
        UPDATE contacts 
        SET name = ?, phone = ?, email = ?, reminder_note = ?, reminder_date = ?, reminder_time = ?
        WHERE id = ? AND user_id = ?
    ");

    $stmt->execute([$name, $phone, $email, $note, $date, $time, $id, $_SESSION['user_id']]);


    // ----------------------------------------------------
    // NEW FEATURE: Insert into reminder_history
    // ----------------------------------------------------
    if (!empty($note) || !empty($date)) {

        $stmt2 = $pdo->prepare("
            INSERT INTO reminder_history 
                (contact_id, note, category, created_date, created_time, reminder_date, status)
            VALUES (?, ?, 'Personal', CURDATE(), CURTIME(), ?, 1)
        ");

        $stmt2->execute([$id, $note, $date]);
    }


    // ⭐ CHECK IF USER PROVIDED ANY EXTRA SETTING
$hasSettings =
    $is_urgent == 1 ||
    $priority_score !== null ||
    $colour_tag !== null ||
    $description !== null;

// --------------------------------------------------------------------------------
// CASE 1: USER CLEARED ALL SETTINGS → DELETE existing settings if they exist
// --------------------------------------------------------------------------------
if (!$hasSettings) {

    if (!empty($settings)) {
        $del = $pdo->prepare("
            DELETE FROM favourite_settings
            WHERE user_id = ? AND contact_id = ?
        ");
        $del->execute([ $_SESSION['user_id'], $id ]);
    }

// do nothing more (no INSERT)
}

// --------------------------------------------------------------------------------
// CASE 2: USER PROVIDED SOME SETTINGS → INSERT or UPDATE
// --------------------------------------------------------------------------------
else {

    if (empty($settings)) {
        // INSERT new settings
        $stmt = $pdo->prepare("
            INSERT INTO favourite_settings 
            (user_id, contact_id, is_urgent, priority_score, colour_tag, description)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $_SESSION['user_id'], 
            $id,
            $is_urgent,
            $priority_score,
            $colour_tag,
            $description
        ]);

    } else {
        // UPDATE existing settings
        $stmt = $pdo->prepare("
            UPDATE favourite_settings
            SET is_urgent = ?, priority_score = ?, colour_tag = ?, description = ?
            WHERE user_id = ? AND contact_id = ?
        ");
        $stmt->execute([
            $is_urgent,
            $priority_score,
            $colour_tag,
            $description,
            $_SESSION['user_id'],
            $id
        ]);
    }
}


    // Redirect after successful update
    header("Location: favourites.php?updated=1");
    exit;
}
?>


<?php

// PROTECT THIS PAGE: Must pass favourite-login first
if (!isset($_SESSION['fav_auth']) || $_SESSION['fav_auth'] !== true) {
    header("Location: favourites.php");
    exit;
}

?>


<!DOCTYPE html>
<html>
<head>
    <title>Edit Favourite Contact</title>

    <style>
        /* NOTHING CHANGED BELOW — your CSS is EXACTLY the same */
        body {
            background: #f4f6fa;
            font-family: "Segoe UI", Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .edit-container {
            max-width: 650px;
            margin: 40px auto;
            background: #fff;
            padding: 35px;
            border-radius: 18px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            font-size: 28px;
            font-weight: 700;
            color: #333;
        }

        .section-title {
            font-size: 20px;
            font-weight: 600;
            margin: 25px 0 10px;
            color: #444;
        }

        label {
            font-weight: 600;
            margin-bottom: 6px;
            display: block;
            color: #555;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ccd1d9;
            font-size: 15px;
            margin-bottom: 18px;
            background: #fafbff;
            transition: .2s;
        }

        textarea {
            height: 90px;
        }

        input:focus, textarea:focus {
            border-color: #5d6df7;
            box-shadow: 0 0 5px rgba(93,109,247,.4);
            outline: none;
        }

        .reminder-box {
            background: #f3f4ff;
            border-left: 4px solid #5d6df7;
            padding: 15px 18px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .save-btn {
            width: 100%;
            background: linear-gradient(135deg, #5d6df7, #8b5cf6);
            color: #fff;
            padding: 14px;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            margin-top: 10px;
            cursor: pointer;
            font-weight: bold;
            transition: .3s;
        }

        .save-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 16px rgba(93,109,247,0.3);
        }

        .back-btn {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-weight: 600;
            color: #5d6df7;
            text-decoration: none;
            padding: 10px;
            border-radius: 8px;
            background: #eef1ff;
        }

        .error {
            background: #ffe2e2;
            padding: 12px;
            border-left: 5px solid #ff4d4d;
            border-radius: 8px;
            margin-bottom: 20px;
            color: #b30000;
            font-weight: 500;
        }
        
    </style>

</head>

<body>

<div class="edit-container">

    <h2>Edit Favourite Contact</h2>

    <!-- Display backend validation errors -->
    <?php if (!empty($errors)): ?>
        <div class="error"><?= implode("<br>", array_map("htmlspecialchars", $errors)) ?></div>
    <?php endif; ?>

    <form method="post">

        <!-- CONTACT INFO -->
        <div class="section-title">Contact Information</div>

        <label>Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($contact['name']) ?>">

        <label>Phone</label>
        <input type="text" name="phone" value="<?= htmlspecialchars($contact['phone']) ?>">

        <label>Email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($contact['email']) ?>">

        <!-- REMINDER SECTION -->
        <div class="section-title">🔔 Reminder Settings</div>

        <div class="reminder-box">
            Add a note & date to get reminded on your dashboard.
        </div>

        <label>Reminder Note</label>
        <textarea 
            name="reminder_note" 
            maxlength="100"
        ><?= htmlspecialchars($contact['reminder_note']) ?></textarea>

        <label>Reminder Date</label>
        <input 
            type="date" 
            name="reminder_date" 
            min="<?= date('Y-m-d'); ?>" 
            value="<?= htmlspecialchars($contact['reminder_date']) ?>"
        >

        <label>Reminder Time</label>
        <input type="time" name="reminder_time" value="<?= htmlspecialchars($contact['reminder_time']) ?>">


        <!-- ⭐ EXTRA FAVOURITE SETTINGS -->
        <div class="section-title">⭐ Extra Favourite Settings</div>

        <label>Is this urgent?</label>
        <input type="checkbox" name="is_urgent"
            <?= (!empty($settings) && $settings['is_urgent'] == 1) ? 'checked' : '' ?>>

        <label>Priority Score (0.00 - 10.00)</label>
        <input type="number" step="0.01" name="priority_score"
            value="<?= $settings['priority_score'] ?? '' ?>">

        <label>Colour Tag</label>
        <input type="text" name="colour_tag" maxlength="20"
            value="<?= $settings['colour_tag'] ?? '' ?>">

        <label>Description</label>
        <textarea name="description"><?= $settings['description'] ?? '' ?></textarea>


        <button type="submit" class="save-btn">Save Changes</button>

    </form>

    <a href="favourites.php" class="back-btn">← Back to Favourites</a>

</div>

</body>
</html>