<?php
require 'config.php'; // Load database settings 
require 'header.php'; // Load page header   
require_login(); // Check user is logged in

// Get contact ID from URL
$id = $_GET['id'] ?? null;
// Check if the ID is empty or not provided
if (!$id) {
    // Redirect user back to contacts list page
    header("Location: view_contacts.php"); 
    // Stop script execution immediately after redirect
    exit;
}

// Get contact data from database
$stmt = $pdo->prepare("SELECT * FROM contacts WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $_SESSION['user_id']]);
$contact = $stmt->fetch();

// Stop if contact not found
if (!$contact) {
    die("Contact not found.");
}

$error = ""; // Variable for error message

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $group_id = $_POST['group_id'] ?? null;
    $country_code = trim($_POST['country_code'] ?? '');

    // Validate required fields
    if ($name === '' || $phone === '') {
        $error = "Name and phone are required.";
    } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email.";
    } else {
        // Format country code
        $country_code = $country_code !== '' ? '+' . preg_replace('/\D+/', '', $country_code) : null;
        // Clean phone number (numbers only)
        $phone_digits = preg_replace('/\D+/', '', $phone);

        // Validate phone number
        if ($phone_digits === '') {
            $error = "Phone is invalid.";
        } else {
           // Check if group belongs to user AND is active
            if (!empty($group_id)) {
                $gstmt = $pdo->prepare(
                    "SELECT id 
                     FROM groups 
                     WHERE id = ? 
                       AND user_id = ? 
                       AND status = 'active'"
                );
                $gstmt->execute([(int)$group_id, $_SESSION['user_id']]);
                if (!$gstmt->fetch()) {
                    $error = "Invalid category selected.";
                }
            } else {
                $group_id = null;
            }
        }

        //  update contact if there are no any errors
        if ($error === "") {
            $stmt = $pdo->prepare("UPDATE contacts SET name=?, phone=?, country_code=?, email=?, group_id=? WHERE id=? AND user_id=?");
            $stmt->execute([$name, $phone_digits, $country_code, $email ?: null, $group_id ?: null, $id, $_SESSION['user_id']]);
            header("Location: view_contacts.php?updated=1"); // Redirect to contacts page
            exit;
        }
    }
}

/// Get user's *ACTIVE* groups for dropdown
$stmt = $pdo->prepare(
    "SELECT id, name 
     FROM groups 
     WHERE user_id = ? 
       AND status = 'active'
     ORDER BY is_favorite DESC, name ASC"
);
$stmt->execute([$_SESSION['user_id']]);
$groups = $stmt->fetchAll();
?>


<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Edit Contact</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .box { max-width:600px; margin:36px auto; background:#fff; padding:18px; border-radius:8px; border:1px solid #e6e9ee; }
        label{display:block; font-weight:600; margin-top:10px;}
        input, select{width:100%; padding:8px; border-radius:6px; border:1px solid #ccc; margin-top:6px;}
        .two { display:flex; gap:8px; }
        .two select, .two input { flex:1; }
        .btn { margin-top:14px; padding:10px 14px; background:#007bff; color:#fff; border:none; border-radius:6px; cursor:pointer; width:100%; }
    </style>
</head>
<body>
<div class="container">
    <div class="box">
        <h2>Edit Contact</h2>

        <?php if ($error): ?>
            <div style="color:#b91c1c; background:#fff1f2; padding:8px; border-radius:6px; margin-bottom:8px;"><?php echo htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post">
            <label>Name</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($contact['name']) ?>">

            <label>Phone</label>
            <div class="two">
                <select name="country_code">
                    <option value="">No code</option>
                    <option value="+45" <?= ($contact['country_code'] ?? '') == '+45' ? 'selected' : '' ?>>+45 (DK)</option>
                    <option value="+1" <?= ($contact['country_code'] ?? '') == '+1' ? 'selected' : '' ?>>+1 (US)</option>
                    <option value="+44" <?= ($contact['country_code'] ?? '') == '+44' ? 'selected' : '' ?>>+44 (UK)</option>
                    <option value="+91" <?= ($contact['country_code'] ?? '') == '+91' ? 'selected' : '' ?>>+91 (IN)</option>
                </select>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($contact['phone']) ?>">
            </div>

            <label>Email</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($contact['email']) ?>">

            <label>Category</label>
            <select name="group_id">
                <option value="">-- Select Category --</option>
                <?php foreach ($groups as $g): ?>
                    <option value="<?= (int)$g['id'] ?>" <?= ($contact['group_id'] == $g['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($g['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="btn">Update Contact</button>
        </form>

        <p style="margin-top:12px;"><a href="view_contacts.php">← Back to Contacts</a></p>
    </div>
</div>
</body>
</html>
