<?php
require 'config.php'; // Database connection
require_login(); // Ensure user is logged in

if (isset($_GET['id'])) {  // Check if contact ID is provided
    $contact_id = (int)$_GET['id']; // Sanitize input       
    
    // Soft delete - set deleted_at timestamp instead of removing
    $stmt = $pdo->prepare('UPDATE contacts SET deleted_at = NOW() WHERE id = ? AND user_id = ?');

    // Execute with contact ID and user ID to ensure security
    $stmt->execute([$contact_id, $_SESSION['user_id']]);
    
    header('Location: view_contacts.php?deleted=1'); // Redirect with success message
    exit;
}
// If no ID provided, redirect back to contacts page
header('Location: view_contacts.php'); 
exit; // Stop script execution
?>