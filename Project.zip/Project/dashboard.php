<?php 
require 'config.php';
require 'header.php';
require_login();

/* ------------------------------
   FETCH TOTAL CONTACT COUNT
--------------------------------*/
$stmt = $pdo->prepare("
    SELECT COUNT(*) 
    FROM contacts 
    WHERE user_id = ? 
      AND deleted_at IS NULL
");
$stmt->execute([$_SESSION['user_id']]);
$total_contacts = $stmt->fetchColumn();

/* ------------------------------
   FETCH FAVOURITE CONTACTS COUNT
--------------------------------*/
$stmt = $pdo->prepare("
    SELECT COUNT(*) 
    FROM contacts 
    WHERE user_id = ? 
      AND deleted_at IS NULL
      AND is_favourite = 1
");
$stmt->execute([$_SESSION['user_id']]);
$favourite_contacts = $stmt->fetchColumn();

/* ------------------------------
   FETCH RECENT CONTACTS
--------------------------------*/
$stmt = $pdo->prepare("
    SELECT 
        c.id, 
        c.name, 
        c.phone, 
        c.country_code,
        c.email, 
        c.is_favourite,
        a.city, 
        a.state
    FROM contacts c
    LEFT JOIN address a ON c.id = a.contact_id
    WHERE c.user_id = ? 
      AND c.deleted_at IS NULL
    ORDER BY c.created_at DESC
    LIMIT 5
");
$stmt->execute([$_SESSION['user_id']]);
$contacts = $stmt->fetchAll();

/* ------------------------------
   FETCH UPCOMING REMINDERS
--------------------------------*/
$stmt = $pdo->prepare("
    SELECT 
        id,
        name,
        reminder_note,
        reminder_date,
        reminder_time
    FROM contacts
    WHERE user_id = ?
      AND is_favourite = 1
      AND reminder_note IS NOT NULL 
      AND reminder_note != ''
      AND reminder_date IS NOT NULL
      AND reminder_time IS NOT NULL
      AND STR_TO_DATE(CONCAT(reminder_date, ' ', reminder_time, ':00'), '%Y-%m-%d %H:%i:%s') >= NOW()
    ORDER BY 
        reminder_date ASC,
        reminder_time ASC
    LIMIT 5
");
$stmt->execute([$_SESSION['user_id']]);
$reminders = $stmt->fetchAll();

/* ------------------------------
   ADMIN STATISTICS (Only for admin users)
--------------------------------*/
$admin_stats = [];
if (is_admin()) {
    $admin_stats['total_users'] = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $admin_stats['total_contacts'] = $pdo->query("SELECT COUNT(*) FROM contacts WHERE deleted_at IS NULL")->fetchColumn();
    $admin_stats['total_groups'] = $pdo->query("SELECT COUNT(*) FROM groups")->fetchColumn();
    $admin_stats['recent_users'] = $pdo->query("SELECT name, email, created_at FROM users ORDER BY created_at DESC LIMIT 3")->fetchAll();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Contact Book</title>

    <style>
/* ==========================
   Dashboard Styling
   ========================== */
:root {
  --primary: #5d6df7;
  --primary-dark: #4a5bd9;
  --primary-light: #e8edff;
  --secondary: #6b7280;
  --accent: #8b5cf6;
  --success: #10b981;
  --warning: #f59e0b;
  --danger: #ef4444;
  --light: #f8fafc;
  --dark: #1f2937;
  --darker: #111827;
  --border: #e5e7eb;
  --shadow: rgba(0, 0, 0, 0.08);
  --shadow-hover: rgba(0, 0, 0, 0.15);
  --admin-color: #dc2626;
  --admin-light: #fef2f2;
}

body {
    background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
    font-family: "Segoe UI", Tahoma, sans-serif;
    margin: 0;
    padding: 0;
    min-height: 100vh;
}

.dash-container {
    max-width: 1200px;
    margin: 30px auto;
    padding: 0 20px 60px;
}

/* Welcome Header */
.welcome-header {
    background: linear-gradient(135deg, var(--primary), var(--accent));
    color: white;
    padding: 30px;
    border-radius: 20px;
    margin-bottom: 30px;
    box-shadow: 0 10px 30px rgba(93, 109, 247, 0.3);
    position: relative;
    overflow: hidden;
}

.welcome-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><circle fill="rgba(255,255,255,0.1)" cx="200" cy="200" r="100"/><circle fill="rgba(255,255,255,0.05)" cx="600" cy="300" r="150"/></svg>');
}

.welcome-content {
    position: relative;
    z-index: 2;
}

.welcome-header h1 {
    margin: 0 0 10px 0;
    font-size: 2.5rem;
    font-weight: 700;
}

.welcome-header p {
    margin: 0;
    opacity: 0.9;
    font-size: 1.1rem;
}

.admin-badge {
    display: inline-block;
    background: var(--admin-light);
    color: var(--admin-color);
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
    margin-left: 10px;
    border: 1px solid var(--admin-color);
}

/* Quick Actions */
.quick-actions h2,
.recent-contacts h2,
.admin-section h2 {
    text-align: center;
    font-size: 32px;
    color: var(--darker);
    margin-bottom: 30px;
    font-weight: 700;
    position: relative;
    padding-bottom: 10px;
}

.quick-actions h2::after,
.recent-contacts h2::after,
.admin-section h2::after {
    content: '';
    position: absolute;
    left: 50%;
    bottom: 0;
    width: 80px;
    height: 4px;
    transform: translateX(-50%);
    background: linear-gradient(90deg, var(--primary), var(--accent));
    border-radius: 4px;
}

.admin-section h2::after {
    background: linear-gradient(90deg, var(--admin-color), var(--warning));
}

.action-buttons {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 25px;
}

.action-btn {
    background: white;
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 30px 25px;
    text-decoration: none;
    text-align: center;
    color: var(--dark);
    box-shadow: 0 4px 20px var(--shadow);
    transition: .3s;
    position: relative;
    overflow: hidden;
}

.action-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(93, 109, 247, 0.1), transparent);
    transition: left 0.5s;
}

.action-btn:hover::before {
    left: 100%;
}

.action-btn:hover {
    transform: translateY(-6px);
    box-shadow: 0 15px 35px var(--shadow-hover);
}

.action-btn.admin-btn {
    border: 2px solid var(--admin-color);
    background: var(--admin-light);
}

.action-btn.admin-btn:hover {
    background: var(--admin-color);
    color: white;
}

.icon {
    font-size: 40px;
    margin-bottom: 12px;
    display: block;
}

/* Overview Cards */
.overview {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px,1fr));
    gap: 30px;
    margin-top: 40px;
}

.card {
    background: white;
    border-radius: 20px;
    padding: 30px;
    border: 1px solid var(--border);
    box-shadow: 0 6px 20px var(--shadow);
    transition: transform 0.3s ease;
}

.card:hover {
    transform: translateY(-5px);
}

.stat-card h3 {
    color: var(--secondary);
    margin: 0 0 15px 0;
    font-size: 1rem;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.stat-card p {
    font-size: 42px;
    font-weight: 800;
    margin: 0;
    background: linear-gradient(135deg, var(--primary), var(--accent));
    -webkit-text-fill-color: transparent;
    -webkit-background-clip: text;
    background-clip: text;
}

.stat-card.favourites p {
    background: linear-gradient(135deg, var(--warning), var(--danger));
    -webkit-text-fill-color: transparent;
    -webkit-background-clip: text;
    background-clip: text;
}

/* Recent contacts section */
.contact-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px,1fr));
    gap: 30px;
    margin-top: 20px;
}

.contact-card {
    background: white;
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 20px;
    position: relative;
    box-shadow: 0 4px 20px var(--shadow);
    transition: .3s;
}

.contact-card:hover {
    transform: translateY(-6px);
    box-shadow: 0 15px 35px var(--shadow-hover);
}

/* Favourite star */
.star-icon {
    float: right;
    font-size: clamp(20px, 4vw, 32px);
    text-decoration: none;
    display: inline-block;
    margin-left: 10px;
    cursor: pointer;
    transition: transform 0.2s ease;
}

.star-icon:hover {
    transform: scale(1.15);
}

/* Admin Section */
.admin-section {
    margin-top: 50px;
    padding: 30px;
    background: var(--admin-light);
    border-radius: 20px;
    border: 2px dashed var(--admin-color);
}

.admin-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.admin-stat-card {
    background: white;
    padding: 20px;
    border-radius: 12px;
    text-align: center;
    border: 1px solid var(--admin-color);
}

.admin-stat-card h4 {
    margin: 0 0 10px 0;
    color: var(--admin-color);
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.admin-stat-card .number {
    font-size: 2rem;
    font-weight: 800;
    color: var(--admin-color);
    margin: 0;
}

.recent-users {
    background: white;
    padding: 20px;
    border-radius: 12px;
    margin-top: 20px;
}

.recent-users h4 {
    margin: 0 0 15px 0;
    color: var(--dark);
}

.user-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.user-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background: var(--light);
    border-radius: 8px;
}

/* Fix float issues on small screens */
@media (max-width: 480px) {
    .star-icon {
        float: none;
        display: inline-block;
        margin-left: 0;
        position: absolute;
        right: 15px;
        top: 15px;
    }

    .contact-card { 
        position: relative; 
    }
    
    .welcome-header h1 {
        font-size: 2rem;
    }
    
    .action-buttons {
        grid-template-columns: 1fr;
    }
    
    .overview {
        grid-template-columns: 1fr;
    }
}

.no-data {
    text-align: center;
    padding: 40px;
    color: var(--secondary);
    background: white;
    border-radius: 16px;
    border: 2px dashed var(--border);
}

.no-data a {
    color: var(--primary);
    text-decoration: none;
    font-weight: 600;
}

.no-data a:hover {
    text-decoration: underline;
}

footer {
    text-align: center;
    padding: 25px;
    background: white;
    border-top: 1px solid var(--border);
    margin-top: 40px;
    color: var(--secondary);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .dash-container {
        padding: 0 15px 40px;
    }
    
    .welcome-header {
        padding: 20px;
    }
    
    .quick-actions h2,
    .recent-contacts h2,
    .admin-section h2 {
        font-size: 24px;
    }
    
    .contact-grid {
        grid-template-columns: 1fr;
    }
}
    </style>
</head>
<body>

<main class="dash-container">

    <!-- Welcome Header -->
    <section class="welcome-header">
        <div class="welcome-content">
            <h1>
                Welcome back, <?= htmlspecialchars($_SESSION['user_name']); ?>!
                <?php if (is_admin()): ?>
                    <span class="admin-badge">ADMIN</span>
                <?php endif; ?>
            </h1>
            <p>Manage your contacts efficiently and stay connected</p>
        </div>
    </section>

    <!-- Quick Actions Section -->
    <section class="quick-actions">
        <h2>Quick Actions</h2>

        <div class="action-buttons">
            <a href="add_contact.php" class="action-btn">
                <span class="icon">➕</span>
                <div class="text">Add New Contact</div>
            </a>

            <a href="view_contacts.php" class="action-btn">
                <span class="icon">👥</span>
                <div class="text">View All Contacts</div>
            </a>

            <a href="manage_groups.php" class="action-btn">
                <span class="icon">📂</span>
                <div class="text">Manage Categories</div>
            </a>

            <a href="favourites.php" class="action-btn">
                <span class="icon">⭐</span>
                <div class="text">Favourite Contacts</div>
            </a>

            <?php if (is_admin()): ?>
                <a href="user_manager.php" class="action-btn admin-btn">
                    <span class="icon">👑</span>
                    <div class="text">User Management</div>
                </a>

                <a href="admin_dashboard.php" class="action-btn admin-btn">
                    <span class="icon">📊</span>
                    <div class="text">Admin Dashboard</div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- Overview Statistics -->
    <section class="overview">
        <div class="card stat-card">
            <h3>Total Contacts</h3>
            <p><?= (int)$total_contacts; ?></p>
        </div>

        <div class="card stat-card favourites">
            <h3>Favourite Contacts</h3>
            <p><?= (int)$favourite_contacts; ?></p>
        </div>

        <div class="card stat-card">
            <h3>Your Profile</h3>
            <p><?= htmlspecialchars($_SESSION['user_name']); ?></p>
        </div>
    </section>

    <!-- Recent Contacts -->
    <section class="recent-contacts">
        <h2>Recent Contacts</h2>

        <?php if (empty($contacts)): ?>
            <div class="no-data">
                <p>You have no contacts yet. <a href="add_contact.php">Add your first contact</a>.</p>
            </div>
        <?php else: ?>
            <div class="contact-grid">
                <?php foreach ($contacts as $c): ?>
                    <div class="contact-card">
                        <h3>
                            <?= htmlspecialchars($c['name']); ?>
                            <?php if ($c['is_favourite'] == 1): ?>
                                <a href="toggle_favourite.php?id=<?= $c['id']; ?>" 
                                   class="star-icon" 
                                   style="color: gold; filter: drop-shadow(0 0 6px gold);">★</a>
                            <?php else: ?>
                                <a href="toggle_favourite.php?id=<?= $c['id']; ?>" 
                                   class="star-icon" 
                                   style="color: #ccc; filter: drop-shadow(0 0 4px #999);">☆</a>
                            <?php endif; ?>
                        </h3>

                        <p>📞 <?= htmlspecialchars($c['country_code'] . " " . $c['phone']); ?></p>
                        <p>✉️ <?= $c['email'] ?: '—'; ?></p>
                        <p>📍 <?= ($c['city'] || $c['state']) ? htmlspecialchars($c['city'] . ", " . $c['state']) : '—'; ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- Upcoming Reminders -->
    <section class="recent-contacts">
        <h2>Upcoming Reminders</h2>

        <?php if (empty($reminders)): ?>
            <div class="no-data">
                <p>No reminders set yet. Edit a favourite contact to add one.</p>
            </div>
        <?php else: ?>
            <div class="contact-grid">
                <?php foreach ($reminders as $r): ?>
                    <div class="card contact-card">
                        <h3><?= htmlspecialchars($r['name']); ?></h3>
                        <p>🗒️ <?= htmlspecialchars($r['reminder_note']); ?></p>
                        <p>📅 <?= htmlspecialchars($r['reminder_date']); ?></p>
                        <p>⏰ <?= htmlspecialchars($r['reminder_time']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- Admin Section (Only for admin users) -->
    <?php if (is_admin()): ?>
        <section class="admin-section">
            <h2>Admin Overview</h2>
            
            <div class="admin-stats">
                <div class="admin-stat-card">
                    <h4>Total Users</h4>
                    <p class="number"><?= $admin_stats['total_users'] ?></p>
                </div>
                <div class="admin-stat-card">
                    <h4>Total Contacts</h4>
                    <p class="number"><?= $admin_stats['total_contacts'] ?></p>
                </div>
                <div class="admin-stat-card">
                    <h4>Total Groups</h4>
                    <p class="number"><?= $admin_stats['total_groups'] ?></p>
                </div>
            </div>

            <div class="recent-users">
                <h4>Recently Registered Users</h4>
                <div class="user-list">
                    <?php foreach ($admin_stats['recent_users'] as $user): ?>
                        <div class="user-item">
                            <span><?= htmlspecialchars($user['name']) ?></span>
                            <small><?= date('M j, Y', strtotime($user['created_at'])) ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

</main>

<footer>
    <p>&copy; 2025 Contact Book - Dashboard</p>
</footer>

</body>
</html>