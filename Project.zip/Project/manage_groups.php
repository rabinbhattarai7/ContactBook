<?php
require 'config.php';
require 'header.php';   
require_login();        

$errors = [];
$editGroup = null;

// =====================================
// DELETE CATEGORY (?delete=ID)
// =====================================
if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];

    if ($deleteId > 0) {
        // delete only if it belongs to the logged-in user
        $stmt = $pdo->prepare("DELETE FROM groups WHERE id = ? AND user_id = ?");
        $stmt->execute([$deleteId, $_SESSION['user_id']]);
    }

    header("Location: manage_groups.php");
    exit;
}


// =====================================
// CREATE / UPDATE CATEGORY (POST)
// =====================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = trim($_POST['name'] ?? '');
    $id          = isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null;
    $is_favorite = isset($_POST['is_favorite']) ? 1 : 0;
    $status      = $_POST['status'] ?? 'active';

    // ---- validation ----
    if ($name === '') {
        $errors[] = 'Category name cannot be empty.';
    }

    if ($name !== '' && mb_strlen($name) > 100) {
        $errors[] = 'Category name cannot be longer than 100 characters.';
    }

    // validate status
    $allowedStatuses = ['active', 'archived'];
    if (!in_array($status, $allowedStatuses, true)) {
        $status = 'active';
    }

    // unique name per user
    if ($name !== '' && empty($errors)) {
        if ($id) {
            $stmt = $pdo->prepare(
                "SELECT COUNT(*) FROM groups 
                 WHERE user_id = ? AND name = ? AND id != ?"
            );
            $stmt->execute([$_SESSION['user_id'], $name, $id]);
        } else {
            $stmt = $pdo->prepare(
                "SELECT COUNT(*) FROM groups 
                 WHERE user_id = ? AND name = ?"
            );
            $stmt->execute([$_SESSION['user_id'], $name]);
        }

        if ((int)$stmt->fetchColumn() > 0) {
            $errors[] = 'You already have a category with this name.';
        }
    }

    // ---- save (insert/update) ----
    if (empty($errors)) {
        if ($id) {
            $stmt = $pdo->prepare(
                "UPDATE groups 
                 SET name = ?, is_favorite = ?, status = ?
                 WHERE id = ? AND user_id = ?"
            );
            $stmt->execute([$name, $is_favorite, $status, $id, $_SESSION['user_id']]);
        } else {
            $stmt = $pdo->prepare(
                "INSERT INTO groups (user_id, name, is_favorite, status) 
                 VALUES (?, ?, ?, ?)"
            );
            $stmt->execute([$_SESSION['user_id'], $name, $is_favorite, $status]);
        }

        header("Location: manage_groups.php");
        exit;
    } else {
        $editGroup = [
            'id'          => $id,
            'name'        => $name,
            'is_favorite' => $is_favorite,
            'status'      => $status,
        ];
    }
}


// =====================================
// LOAD CATEGORY FOR EDIT (?edit=ID)
// =====================================
if ($editGroup === null && isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];

    if ($editId > 0) {
        $stmt = $pdo->prepare(
            "SELECT * FROM groups 
             WHERE id = ? AND user_id = ?"
        );
        $stmt->execute([$editId, $_SESSION['user_id']]);
        $editGroup = $stmt->fetch();
    }
}


// =====================================
// SEARCH + SORT SETUP
// =====================================
$q    = trim($_GET['q'] ?? '');
$sort = $_GET['sort'] ?? 'name_asc';

switch ($sort) {
    case 'name_desc':
        $orderBy = 'name DESC';
        break;
    case 'newest':
        $orderBy = 'id DESC';
        break;
    case 'oldest':
        $orderBy = 'id ASC';
        break;
    case 'favorite':
        $orderBy = 'is_favorite DESC, name ASC';
        break;
    case 'name_asc':
    default:
        $orderBy = 'name ASC';
        $sort = 'name_asc';
        break;
}


// =====================================
// FETCH ALL CATEGORIES FOR USER
// =====================================
if ($q !== '') {
    $stmt = $pdo->prepare(
        "SELECT * FROM groups 
         WHERE user_id = ? 
           AND name LIKE ?
         ORDER BY $orderBy"
    );
    $stmt->execute([$_SESSION['user_id'], '%' . $q . '%']);
} else {
    $stmt = $pdo->prepare(
        "SELECT * FROM groups 
         WHERE user_id = ? 
         ORDER BY $orderBy"
    );
    $stmt->execute([$_SESSION['user_id']]);
}

$groups          = $stmt->fetchAll();
$isEditing       = $editGroup && isset($editGroup['id']);
$currentStatus   = $editGroup['status'] ?? 'active';
$currentFavorite = !empty($editGroup['is_favorite']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories - Contact Book</title>
    <link rel="stylesheet" href="assets/style.css">

    <style>
        :root {
            --primary: #4a6cf7;
            --primary-light: #eef2ff;
            --secondary: #6c757d;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
            --border: #dee2e6;
            --shadow: rgba(0, 0, 0, 0.1);
            --archived-bg: #f3f3f3;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--dark);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
        }

        .container {
            max-width: 800px;
            margin: 80px auto 0;
        }

        .content {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px var(--shadow);
            margin-bottom: 30px;
        }

        h2 {
            color: var(--primary);
            font-weight: 700;
            font-size: 28px;
            text-align: center;
            margin: 0 0 10px;
        }

        .subtitle {
            text-align: center;
            color: var(--secondary);
            margin-bottom: 20px;
            font-size: 14px;
        }

        .add-form {
            background: var(--light);
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
            border: 1px solid var(--border);
        }

        .form-group {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: flex-end;
        }

        input[type="text"] {
            flex: 1 1 200px;
            padding: 12px 15px;
            border-radius: 8px;
            border: 1px solid var(--border);
            font-size: 16px;
        }

        .btn {
            padding: 12px 20px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
        }

        .btn-secondary {
            padding: 10px 16px;
            background: var(--secondary);
            color: white;
            border-radius: 8px;
            font-size: 14px;
            text-decoration: none;
        }

        .categories-list {
            margin-top: 30px;
        }

        .category-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background: white;
            border: 1px solid var(--border);
            border-radius: 8px;
            margin-bottom: 12px;
        }

        .category-item.archived {
            background: var(--archived-bg);
            opacity: 0.9;
        }

        .category-main {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .favorite-icon {
            font-size: 18px;
        }

        .favorite-icon.active {
            color: #f5c518;
        }

        .category-name {
            font-weight: 600;
            font-size: 16px;
        }

        .status-badge {
            padding: 2px 8px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-badge.active {
            background: #e0f7e9;
            color: #137333;
        }

        .status-badge.archived {
            background: #f1f3f4;
            color: #5f6368;
        }

        .category-actions {
            display: flex;
            gap: 8px;
        }

        .edit-btn,
        .delete-btn {
            border-radius: 6px;
            padding: 8px 15px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
        }

        .edit-btn {
            background: var(--primary-light);
            color: var(--primary);
        }

        .delete-btn {
            background: var(--danger);
            color: #fff;
        }

        .empty-state {
            padding: 40px;
            text-align: center;
            color: var(--secondary);
            background: var(--light);
            border-radius: 10px;
            border: 1px dashed var(--border);
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
        }

        /* Search & Sort */
        .search-sort-bar {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .search-sort-bar input[type="text"] {
            flex: 1 1 180px;
            padding: 10px 12px;
            border-radius: 8px;
            border: 1px solid var(--border);
        }

        .search-sort-bar select {
            padding: 10px 12px;
            border-radius: 8px;
            border: 1px solid var(--border);
        }

        /* Favorite toggle */
        .favorite-toggle {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 14px;
            color: var(--secondary);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="content">
            <h2>Manage Categories</h2>

            <div class="subtitle">
                <?php if ($isEditing): ?>
                    Editing category
                <?php elseif ($q !== ''): ?>
                    Showing results for "<?= htmlspecialchars($q) ?>"
                <?php else: ?>
                    Create, edit & organize your categories.
                <?php endif; ?>
            </div>

            <div class="add-form">
                <?php if (!empty($errors)): ?>
                    <div class="error-message">
                        <strong>Please fix the following:</strong>
                        <ul>
                            <?php foreach ($errors as $e): ?>
                                <li><?= htmlspecialchars($e) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="post">
                    <div class="form-group">

                        <input type="hidden" name="id"
                               value="<?= $isEditing ? (int)$editGroup['id'] : '' ?>">

                        <input type="text"
                               name="name"
                               placeholder="Enter category name"
                               required
                               value="<?= htmlspecialchars($editGroup['name'] ?? '') ?>">

                        <label class="favorite-toggle">
                            <input type="checkbox" name="is_favorite"
                                   <?= $currentFavorite ? 'checked' : '' ?>>
                            ⭐ Favorite
                        </label>

                        <select name="status">
                            <option value="active"   <?= $currentStatus === 'active'   ? 'selected' : '' ?>>Active</option>
                            <option value="archived" <?= $currentStatus === 'archived' ? 'selected' : '' ?>>Archived</option>
                        </select>

                        <button type="submit" class="btn">
                            <?= $isEditing ? '💾 Update' : '➕ Add' ?>
                        </button>

                        <?php if ($isEditing): ?>
                            <a href="manage_groups.php" class="btn-secondary">Cancel</a>
                        <?php endif; ?>

                    </div>
                </form>

            </div>


            <div class="categories-list">

                <form method="get" class="search-sort-bar">
                    <input type="text" name="q"
                           placeholder="Search..."
                           value="<?= htmlspecialchars($q) ?>">

                    <select name="sort">
                        <option value="name_asc"  <?= $sort === 'name_asc'  ? 'selected' : '' ?>>Name A–Z</option>
                        <option value="name_desc" <?= $sort === 'name_desc' ? 'selected' : '' ?>>Name Z–A</option>
                        <option value="favorite"  <?= $sort === 'favorite'  ? 'selected' : '' ?>>Favorites first</option>
                        <option value="newest"    <?= $sort === 'newest'    ? 'selected' : '' ?>>Newest first</option>
                        <option value="oldest"    <?= $sort === 'oldest'    ? 'selected' : '' ?>>Oldest first</option>
                    </select>

                    <button type="submit" class="btn-secondary">Search</button>

                    <?php if ($q !== '' || $sort !== 'name_asc'): ?>
                        <a href="manage_groups.php" class="btn-secondary">Reset</a>
                    <?php endif; ?>
                </form>


                <?php if (empty($groups)): ?>
                    <div class="empty-state">
                        No categories found.
                    </div>
                <?php else: ?>
                    <?php foreach ($groups as $g): ?>
                        <?php
                        $isFav  = !empty($g['is_favorite']);
                        $status = $g['status'];
                        ?>
                        <div class="category-item <?= $status === 'archived' ? 'archived' : '' ?>">

                            <div class="category-main">
                                <span class="favorite-icon <?= $isFav ? 'active' : '' ?>">
                                    <?= $isFav ? '★' : '☆' ?>
                                </span>

                                <span class="category-name">
                                    <?= htmlspecialchars($g['name']) ?>
                                </span>

                                <span class="status-badge <?= $status ?>">
                                    <?= ucfirst($status) ?>
                                </span>
                            </div>

                            <div class="category-actions">
                                <a href="?edit=<?= (int)$g['id'] ?>" class="edit-btn">✏️ Edit</a>

                                <a href="?delete=<?= (int)$g['id'] ?>"
                                   class="delete-btn"
                                   onclick="return confirm('Delete this category?')">
                                   🗑️ Delete
                                </a>
                            </div>

                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <a href="view_contacts.php" class="back-link">← Back to Contacts</a>

        </div>
    </div>

</body>
</html>