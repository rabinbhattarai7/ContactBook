<?php
// Start session only if it isn't already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Simple helper function: checks if a user is logged in
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Check if user is admin (you'll need to implement this based on your user system)
function is_admin() {
    // This should check if the logged-in user has admin privileges
    // For example: return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    // For now, we'll assume you have this implemented
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Book</title>
    <style>
    /* ---------- HEADER NAV BAR ---------- */

    .main-header {
        background: #ffffff;
        padding: 18px 0;
        box-shadow: 0 2px 12px rgba(0,0,0,0.10);
        position: sticky;
        top: 0;
        z-index: 1000;
    }

    .nav-container {
        max-width: 1250px;
        margin: auto;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 25px;
    }

    .site-logo {
        font-size: 24px;
        font-weight: 700;
        color: #4a6cf7;
        text-decoration: none;
        letter-spacing: 0.5px;
    }

    .nav-menu {
        display: flex;
        align-items: center;
    }

    .nav-menu a {
        margin-left: 22px;
        text-decoration: none;
        color: #4b5563;
        font-size: 15px;
        font-weight: 500;
        padding: 8px 14px;
        border-radius: 6px;
        transition: 0.25s ease;
    }

    .nav-menu a:hover {
        background: #eef2ff;
        color: #4a6cf7;
    }

    .admin-link {
        color: #8b5cf6 !important;
        font-weight: 600;
    }

    .admin-link:hover {
        background: #f3f0ff !important;
        color: #7c3aed !important;
    }

    .logout-btn {
        color: #dc3545 !important;
        font-weight: 600;
    }

    .logout-btn:hover {
        background: #ffe5e5;
        color: #b02a37 !important;
    }

    /* Optional active link highlight */
    .nav-menu a.active {
        background: #eef2ff;
        color: #4a6cf7;
    }
    </style>
</head>
<body>
    <!-- ---------- HEADER SECTION WITH NAVIGATION LINKS ---------- -->
    <header class="main-header">
        <div class="nav-container">

            <!-- Logo linking back to dashboard -->
            <a href="dashboard.php" class="site-logo">📘 Contact Book</a>

            <!-- Main navigation menu for the system -->
            <nav class="nav-menu">
                <a href="dashboard.php">Dashboard</a>
                <a href="view_contacts.php">My Contacts</a>
                <a href="add_contact.php">Add Contact</a>
                <a href="favourites.php">⭐ Favourite Contacts</a>
                <a href="trash.php">🗑️ Trash</a>
                
                <!-- Admin-only navigation links -->
                <?php if (is_admin()): ?>
                    <a href="user_manager.php" class="admin-link">User Management</a>
                    <a href="admin_dashboard.php" class="admin-link">Admin Dashboard</a>
                <?php endif; ?>
                
                <a href="logout.php" class="logout-btn">Logout</a>
            </nav>

        </div>
    </header>