<?php
require 'config.php'; // Load database connection

// Array to store error messages
$errors = [];
// Variable to track success status
$success = false;

// Common security questions
$security_questions = get_security_questions();

// Check if registration form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data and remove extra spaces
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $security_question = trim($_POST['security_question'] ?? '');
    $security_answer = trim($_POST['security_answer'] ?? '');

    // Basic validation checks
    if ($name === '' || $email === '' || $password === '' || $security_question === '' || $security_answer === '') {
        $errors[] = 'All fields are required.';
    } elseif (!validate_email($email)) {
        $errors[] = 'Invalid email format.';
    } elseif (strlen($name) < 2 || strlen($name) > 100) {
        $errors[] = 'Name must be between 2 and 100 characters.';
    } elseif ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters long.';
    } else {
        // Validate security data
        $security_errors = validate_security_data($security_question, $security_answer);
        if (!empty($security_errors)) {
            $errors = array_merge($errors, $security_errors);
        }

        // Check password strength
        if (strlen($password) < 8) {
            $errors[] = 'For better security, use a password with at least 8 characters.';
        }

        // Check if email already exists in database
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'An account with this email already exists.';
        }
    }

    // If no errors, create account
    if (empty($errors)) {
        // Create new user account
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $hashed_answer = password_hash(strtolower(trim($security_answer)), PASSWORD_DEFAULT);
        
        $pdo->beginTransaction();
        try {
            // Insert user with default role and active status
            $stmt = $pdo->prepare('INSERT INTO users (name, email, password, security_question, security_answer, role, is_active) VALUES (?, ?, ?, ?, ?, "user", 1)');
            $stmt->execute([$name, $email, $hash, $security_question, $hashed_answer]);
            $user_id = $pdo->lastInsertId();

            // Automatically add default categories for this user
            $defaultGroups = ['Family', 'Friends', 'Business', 'Work'];
            $groupStmt = $pdo->prepare('INSERT INTO groups (user_id, name) VALUES (?, ?)');
            foreach ($defaultGroups as $groupName) {
                $groupStmt->execute([$user_id, $groupName]);
            }

            $pdo->commit();
            
            // Log the activity
            if (function_exists('log_activity')) {
                log_activity($user_id, 'registration_successful', 'New user registered with security question');
            }

            // Redirect to login page with success message
            header('Location: login.php?registered=1');
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            error_log('Registration failed: ' . $e->getMessage());
            $errors[] = 'Registration failed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Contact Book</title>
    <link rel="stylesheet" href="assets/home.css">
    <style>
        .security-section {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            border-left: 4px solid #5d6df7;
        }
        
        .security-note {
            font-size: 0.85rem;
            color: #6c757d;
            margin-top: 8px;
            line-height: 1.4;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .password-strength {
            margin-top: 8px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        .strength-weak { color: #dc3545; }
        .strength-medium { color: #fd7e14; }
        .strength-strong { color: #28a745; }
        
        .requirements {
            background: #e8f4fd;
            border: 1px solid #b8daff;
            border-radius: 8px;
            padding: 15px;
            margin: 15px 0;
            font-size: 0.85rem;
        }
        
        .requirement-item {
            margin: 5px 0;
            display: flex;
            align-items: center;
        }
        
        .requirement-item.valid {
            color: #28a745;
        }
        
        .requirement-item.invalid {
            color: #6c757d;
        }
        
        .progress-bar {
            height: 4px;
            background: #e9ecef;
            border-radius: 2px;
            margin-top: 5px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            transition: all 0.3s ease;
        }
        
        .security-icon {
            color: #5d6df7;
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <!-- Page header section -->
    <header class="small-header">
        <div class="container">
            <h1 class="logo">Contact Book</h1>
        </div>
    </header>

    <!-- Main content area -->
    <main class="auth-page">
        <div class="auth-card">
            <h2>Create Your Account</h2>
            <p class="subtitle">Join thousands managing their contacts securely</p>

            <!-- Security notice -->
            <div class="security-notice" style="background: #fff3cd; border-color: #ffeaa7; color: #856404;">
                🔒 Your data is secured with enterprise-grade encryption
            </div>

            <!-- Show error messages if any exist -->
            <?php if (!empty($errors)): ?>
                <div class="error">❌ <?php echo implode('<br>', array_map('htmlspecialchars', $errors)); ?></div>
            <?php endif; ?>

            <!-- Password requirements -->
            <div class="requirements">
                <strong>Password Requirements:</strong>
                <div class="requirement-item" id="req-length">✓ At least 6 characters (8 recommended)</div>
                <div class="requirement-item" id="req-upper">✓ Include uppercase letters</div>
                <div class="requirement-item" id="req-lower">✓ Include lowercase letters</div>
                <div class="requirement-item" id="req-number">✓ Include numbers</div>
                <div class="requirement-item" id="req-special">✓ Include special characters</div>
            </div>

            <!-- Registration form -->
            <form method="post" action="register.php" id="registrationForm">
                <!-- Personal Information -->
                <div class="form-group">
                    <label for="name">Full Name *</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($name ?? '') ?>" 
                           placeholder="Enter your full name" required minlength="2" maxlength="100"
                           autocomplete="name">
                </div>

                <div class="form-group">
                    <label for="email">Email Address *</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($email ?? '') ?>" 
                           placeholder="Enter your email address" required
                           autocomplete="email">
                </div>

                <div class="form-group">
                    <label for="password">Password *</label>
                    <input type="password" id="password" name="password" 
                           placeholder="Create a strong password" required minlength="6"
                           oninput="checkPasswordStrength(this.value)"
                           autocomplete="new-password">
                    <div class="progress-bar">
                        <div class="progress-fill" id="password-progress"></div>
                    </div>
                    <div id="password-strength" class="password-strength"></div>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm Password *</label>
                    <input type="password" id="confirm_password" name="confirm_password" 
                           placeholder="Confirm your password" required minlength="6"
                           oninput="checkPasswordMatch()"
                           autocomplete="new-password">
                    <div id="password-match" class="password-strength"></div>
                </div>

                <!-- Security Questions Section -->
                <div class="security-section">
                    <h4 style="margin-top: 0; color: #495057; display: flex; align-items: center;">
                        <span class="security-icon">🔐</span>
                        Security Settings
                    </h4>
                    <p class="security-note">
                        This information will be used to verify your identity if you ever forget your password.
                        Choose a question that only you can answer.
                    </p>

                    <div class="form-group">
                        <label for="security_question">Security Question *</label>
                        <select id="security_question" name="security_question" required>
                            <option value="">Choose a security question...</option>
                            <?php foreach ($security_questions as $question): ?>
                                <option value="<?= htmlspecialchars($question) ?>" 
                                    <?= (isset($security_question) && $security_question === $question) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($question) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="security_answer">Security Answer *</label>
                        <input type="text" id="security_answer" name="security_answer" 
                               value="<?= htmlspecialchars($security_answer ?? '') ?>" 
                               placeholder="Enter your secret answer" required minlength="2" maxlength="100"
                               autocomplete="off">
                        <p class="security-note">
                            ⚠️ Your answer is case-insensitive and will be stored securely using military-grade encryption.
                            Make sure it's memorable but not easy to guess.
                        </p>
                    </div>
                </div>

                <!-- Submit button -->
                <button type="submit" class="btn btn-primary full-width" id="submitBtn">
                    Create Secure Account
                </button>
            </form>

            <!-- Link to login page -->
            <p class="switch">
                Already have an account? <a href="login.php">Sign in here</a>
            </p>
        </div>
    </main>

    <!-- Page footer -->
    <footer>
        <div class="container">
            <p>&copy; 2025 Contact Book - Enterprise Contact Management</p>
        </div>
    </footer>

    <script>
        function checkPasswordStrength(password) {
            const strengthElement = document.getElementById('password-strength');
            const progressElement = document.getElementById('password-progress');
            let strength = 0;
            let strengthText = '';
            let strengthClass = '';
            
            // Requirements elements
            const reqLength = document.getElementById('req-length');
            const reqUpper = document.getElementById('req-upper');
            const reqLower = document.getElementById('req-lower');
            const reqNumber = document.getElementById('req-number');
            const reqSpecial = document.getElementById('req-special');
            
            if (password.length === 0) {
                strengthElement.innerHTML = '';
                progressElement.style.width = '0%';
                progressElement.style.background = '';
                resetRequirements();
                return;
            }
            
            // Check requirements
            const hasMinLength = password.length >= 6;
            const hasUpper = /[A-Z]/.test(password);
            const hasLower = /[a-z]/.test(password);
            const hasNumber = /\d/.test(password);
            const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
            
            // Update requirement indicators
            updateRequirement(reqLength, hasMinLength);
            updateRequirement(reqUpper, hasUpper);
            updateRequirement(reqLower, hasLower);
            updateRequirement(reqNumber, hasNumber);
            updateRequirement(reqSpecial, hasSpecial);
            
            // Calculate strength
            if (password.length >= 6) strength += 20;
            if (password.length >= 8) strength += 10;
            if (hasUpper) strength += 20;
            if (hasLower) strength += 20;
            if (hasNumber) strength += 15;
            if (hasSpecial) strength += 15;
            
            // Determine strength level
            if (strength < 40) {
                strengthText = 'Weak';
                strengthClass = 'strength-weak';
                progressElement.style.background = '#dc3545';
            } else if (strength < 70) {
                strengthText = 'Medium';
                strengthClass = 'strength-medium';
                progressElement.style.background = '#fd7e14';
            } else {
                strengthText = 'Strong';
                strengthClass = 'strength-strong';
                progressElement.style.background = '#28a745';
            }
            
            progressElement.style.width = Math.min(strength, 100) + '%';
            strengthElement.innerHTML = `<span class="${strengthClass}">Password Strength: ${strengthText}</span>`;
        }
        
        function updateRequirement(element, isValid) {
            if (isValid) {
                element.classList.add('valid');
                element.classList.remove('invalid');
                element.innerHTML = '✓ ' + element.innerHTML.replace(/[✓✗]\s*/, '');
            } else {
                element.classList.add('invalid');
                element.classList.remove('valid');
                element.innerHTML = '✗ ' + element.innerHTML.replace(/[✓✗]\s*/, '');
            }
        }
        
        function resetRequirements() {
            const requirements = document.querySelectorAll('.requirement-item');
            requirements.forEach(req => {
                req.classList.remove('valid', 'invalid');
                req.innerHTML = '✗ ' + req.innerHTML.replace(/[✓✗]\s*/, '');
            });
        }
        
        function checkPasswordMatch() {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const matchElement = document.getElementById('password-match');
            
            if (confirmPassword.length === 0) {
                matchElement.innerHTML = '';
                return;
            }
            
            if (password === confirmPassword) {
                matchElement.innerHTML = '<span class="strength-strong">✅ Passwords match</span>';
            } else {
                matchElement.innerHTML = '<span class="strength-weak">❌ Passwords do not match</span>';
            }
        }
        
        // Form validation and UX improvements
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('registrationForm');
            const submitBtn = document.getElementById('submitBtn');
            
            // Real-time form validation
            form.addEventListener('input', function() {
                const inputs = form.querySelectorAll('input[required], select[required]');
                let allFilled = true;
                
                inputs.forEach(input => {
                    if (!input.value.trim()) {
                        allFilled = false;
                    }
                });
                
                // Check password match
                const password = document.getElementById('password').value;
                const confirmPassword = document.getElementById('confirm_password').value;
                const passwordsMatch = password === confirmPassword && password.length >= 6;
                
                submitBtn.disabled = !allFilled || !passwordsMatch;
            });
            
            // Initial check
            form.dispatchEvent(new Event('input'));
            
            // Clear error styling on input
            const inputs = form.querySelectorAll('input, select');
            inputs.forEach(input => {
                input.addEventListener('input', function() {
                    this.style.borderColor = '';
                });
            });
        });
    </script>
</body>
</html>